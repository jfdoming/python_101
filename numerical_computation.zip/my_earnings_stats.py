import numpy
from numpy import genfromtxt

BASE_IDX = ...
LAST_IDX = ...
WAGE_IDX = ... - BASE_IDX
HOURS_IDX = ... - BASE_IDX
OT_IDX = ... - BASE_IDX

data = genfromtxt(
    "earnings.csv",
    delimiter=",",
    skip_header=True,
    usecols=range(BASE_IDX, LAST_IDX + 1),
)


# Data processing.
earned = ...

# Statistics.
minimum = ...
maximum = ...
avg = ...
std = ...

# Percentile.
pct_75_cutoff = ...
pct_75 = ...

# Output.
print("Minimum earned:", minimum)
print("Maximum earned:", maximum)
print("Average earned:", avg)
print("Standard deviation of earnings:", std)
print("Cutoff for 75th percentile:", pct_75_cutoff)
print("Earnings above 75th percentile:", pct_75)
