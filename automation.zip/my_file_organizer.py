# Imports.
...


def is_fruit_article(article: str) -> bool:
    ...


def is_university_article(article: str) -> bool:
    ...


def get_article_class(article: str) -> str:
    # Use the functions from above to determine the class.
    ...


def get_article_name(article: str) -> str:
    # Get the title of the article.
    ...

    # Get the actual name being referred to.
    ...


def process_article(path_to_article: str):
    # Read the article.
    ...

    # Determine where we want to move the article to.
    ...

    # Move the article.
    ...


# Check where to load the data from.
...

# Remove any work from previous runs.
...

# Create all the output directories.
...

# Loop over all the data files and process each article.
...
